# Somil's Study Hub

## Features
- To-Do list (with local save)
- Notes (auto save in browser)
- Backup & Restore (JSON file)
- Light/Dark mode toggle

## How to Use
1. Open `index.html` in your browser to use locally.
2. To host online:
   - Upload `index.html`, `style.css`, `script.js` to GitHub repository.
   - Enable GitHub Pages in settings.
   - Your site goes live!

## Backup/Restore
- Click **Download Backup** to save your data as `backup.json`.
- Upload the file via **Restore** to get your data back.
